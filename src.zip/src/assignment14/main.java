package assignment14;

import view.LoginPanel;
import view.View;

public class  main{
  public static void main(String[] args) {
	/* java.awt.EventQueue.invokeLater(new Runnable(){
		  public void run(){
			  new LoginPanel().setVisible(true);
		  }
	  });*/
	LoginPanel login = new LoginPanel();
  
 
  }
}
